<?php namespace App\Http\Controllers\Auth;
 
use App\User;
use DB;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Guard;
 
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
 
class AuthController extends Controller {
 
    /**
     * the model instance
     * @var User
     */
    protected $user; 
    /**
     * The Guard implementation.
     *
     * @var Authenticator
     */
    protected $auth;
 
    /**
     * Create a new authentication controller instance.
     *
     * @param  Authenticator  $auth
     * @return void
     */
    public function __construct(Guard $auth, User $user)
    {
        \Log::info("in the constructor function of auth controller");
       
        $this->user = $user; 
        $this->auth = $auth;
 
        $this->middleware('guest', ['except' => ['getLogout']]); 
    }
 
    /**
     * Show the application registration form.
     *
     * @return Response
     */
    public function getRegister()
    {
        return view('auth.register');
    }
 
    /**
     * Handle a registration request for the application.
     *
     * @param  RegisterRequest  $request
     * @return Response
     */
    public function postRegister(RegisterRequest $request)
    {
        //code for registering a user goes here.
        $this->auth->login($this->user); 
        return redirect('/dash-board'); 
    }
 
    /**
     * Show the application login form.
     *
     * @return Response
     */
    public function getLogin()
    {
        return view('auth.login');
    }
 
    /**
     * Handle a login request to the application.
     *
     * @param  LoginRequest  $request
     * @return Response
     */
    public function postLogin(LoginRequest $request)
    {
        \Log::info("-----------------this is fucking working right now i am in new database driver auth controller.php");
       
         $a = array ('username' => $request->input('email'), 'password' => $request->input('password'));
       $tasks = DB::select('SELECT * FROM tasks where user_id = 6;');
        \Log::info($tasks);
        \Log::info("trying to attepm to loging");
       
        if ($this->auth->attempt($a))
        {
            return view('tasks.index',['tasks' => $tasks]);
        }

     /*   if ($this->auth->attempt($request->only('email', 'password')))
        {
            return redirect('/tasks');
        }

    */
 
        return redirect('auth/login')->withErrors([
            'email' => 'The credentials you entered did not match our records. Try again?',
        ]);
    }
 
    /**
     * Log the user out of the application.
     *
     * @return Response
     */
    public function getLogout()
    {
        $this->auth->logout();
 
        return redirect('/');
    }
 
}